//Ambrogiani Filippo 3i 03/05/2023
using System;
using System.Collections.Generic;
using System.Linq;

public static class LargestSeriesProduct
{
    public static long GetLargestProduct(string digits, int span) 
    {
        int maggiore = 0;
        char[] vet = digits.ToCharArray();
        int length = digits.Length;

        if(span > length){
            throw new System.ArgumentException();
        }
        if(span < 0){
            throw new System.ArgumentException();
        }
        if(span == 0){
            return 1;
        }

        for (int i = 0; i < length; i++){
            if(char.IsLetter(vet[i])){
                throw new System.ArgumentException();                
            }
        }

        for (int i = 0; i <= length-span; i++)
        {
            
            int tmp = i;
            int prodotto = 1;

            for (int x = 0; x < span; x++)
            {
                prodotto = prodotto * (vet[tmp]-48);
                tmp += 1;
            }  
            if(maggiore < prodotto)
            {
                maggiore = prodotto;
            }
        }
        return maggiore;
    }
}